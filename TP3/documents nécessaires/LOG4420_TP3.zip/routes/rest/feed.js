const express = require('express')

module.exports = serviceFeed => {
  const router = express.Router()

  // À COMPLÉTER

  return router
}
