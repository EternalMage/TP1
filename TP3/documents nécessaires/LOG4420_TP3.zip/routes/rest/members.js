const express = require('express')

module.exports = serviceTeam => {
  const router = express.Router()

  // À COMPLÉTER

  return router
}
