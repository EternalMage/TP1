import React from 'react'

import './PublicationTable.css'

const pug = window.pug

export default props => {

  return pug``
}
