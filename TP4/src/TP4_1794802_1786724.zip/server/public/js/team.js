// import EmailObfuscate from 'email-obfuscate'

document.addEventListener('DOMContentLoaded', event => {
  document.getElementById('team-link').classList.add('active')

// const emails = document.getElementsByClassName('email')
// for (var i = 0; i < emails.length; i++) {
//   EmailObfuscate(emails[i], {
//     // Email construct: name@domain.tld
//     name: 'test',
//     domain: 'example',
//     tld: 'com',
//     // Alternate Text
//     altText: 'Email'
//   })
// }
})
